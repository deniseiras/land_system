#include "b2o_config.h"

module b2o_common

#ifdef B2O_HAVE_IFSAUX
use parkind1, only : JPIM, JPRD
#endif

use yomhook, only : lhook, dr_hook

use eccodes

implicit none

#ifdef B2O_HAVE_IFSAUX
private :: JPIM, JPRD
integer, parameter :: B2O_INT = JPIM
integer, parameter :: B2O_DOUBLE = JPRD
#else
integer, parameter :: B2O_INT = selected_int_kind(9)
integer, parameter :: B2O_DOUBLE = selected_real_kind(13, 300)
#endif

integer(b2o_int), parameter :: ODB_IGNORE = 0
integer(b2o_int), parameter :: ODB_INTEGER = 1
integer(b2o_int), parameter :: ODB_REAL = 2
integer(b2o_int), parameter :: ODB_STRING = 3
integer(b2o_int), parameter :: ODB_BITFIELD = 4
integer(b2o_int), parameter :: ODB_DOUBLE = 5

real(b2o_double), parameter :: BUFR_MISSING_REAL = 1.7e38_B2O_DOUBLE
real(b2o_double), parameter :: B2O_GRAVITY = 9.80665_B2O_DOUBLE
real(b2o_double), parameter :: ODB_MISSING_REAL = -2147483647
integer(b2o_int), parameter :: ODB_MISSING_INT = 2147483647

! For backward compatibility
real(b2o_double), parameter :: RVIND = BUFR_MISSING_REAL

integer(b2o_int), parameter :: B2O_DEBUG = 0
integer(b2o_int), parameter :: B2O_INFO = 1
integer(b2o_int), parameter :: B2O_WARNING = 2
integer(b2o_int), parameter :: B2O_ERROR = 3

integer(b2o_int), parameter :: B2O_SUCCESS = 0
integer(b2o_int), parameter :: B2O_END_OF_FILE = -1
integer(b2o_int), parameter :: B2O_IO_ERROR = -2
integer(b2o_int), parameter :: B2O_SKIP_MESSAGE = -3
integer(b2o_int), parameter :: B2O_UNSUPPORTED_SUBTYPE = -4
integer(b2o_int), parameter :: B2O_ASSERTION_ERROR = -5
integer(b2o_int), parameter :: B2O_DECODING_ERROR = -6
integer(b2o_int), parameter :: B2O_UNRECOGNIZED_TABLE = -7
integer(b2o_int), parameter :: B2O_INTERNAL_ERROR = -8
integer(b2o_int), parameter :: B2O_VALUE_ERROR = -9

integer(b2o_int), parameter :: B2O_KIND_UNKNOWN = 0
integer(b2o_int), parameter :: B2O_KIND_HEADER = 1
integer(b2o_int), parameter :: B2O_KIND_BODY = 2

integer(b2o_int), parameter :: B2O_NO_SKIP_EXTRA_KEY_ATTRIBUTES(8) = [0, 1, 2, 3, 170, 172, 176, 178]

integer(b2o_int), parameter :: B2O_MAX_KEY_LEN = 256

interface

subroutine b2o_log_proc(level, message, mpi_rank)
    implicit none
    integer(4), intent(in) :: level
    character(len=*), intent(in) :: message
    integer(4), intent(in) :: mpi_rank
end subroutine

subroutine b2o_c_log_proc(level, message)
    use, intrinsic :: iso_c_binding
    implicit none
    integer(c_int), value :: level
    character(kind=c_char), dimension(*) :: message
end subroutine

end interface

type b2o_context_t
    character(len=256) :: message_source = ""
    integer(b2o_int) :: message_number = 0
    integer(b2o_int) :: seqno = 1
    integer(b2o_int) :: odb_handle
    integer(b2o_int) :: pool_number
    integer(b2o_int) :: number_of_pools
    integer(b2o_int) :: log_level
    integer(b2o_int) :: mpi_rank = 0
    integer(b2o_int), pointer :: subsets_per_pool(:)
    character(len=1024) :: subsets_per_pool_file = ""
    logical :: is_inited = .false.
    logical :: is_default = .false.
    procedure(b2o_log_proc), pointer, nopass :: log_proc => null()
    procedure(b2o_c_log_proc), pointer, nopass :: c_log_proc => null()
    type(b2o_context_t), pointer :: self => null()
end type

character(len=32), dimension(12), parameter :: ODB_HEADER_TABLES = (/ &
    "collocated_imager_information", &
    "conv                         ", &
    "gnssro                       ", &
    "hdr                          ", &
    "radiance                     ", &
    "resat                        ", &
    "sat                          ", &
    "satob                        ", &
    "scatt                        ", &
    "smos                         ", &
    "aeolus_hdr                   ", &
    "aeolus_l2b                   "  &
/)

character(len=32), dimension(6), parameter :: ODB_BODY_TABLES = (/ &
    "body                  ", &
    "conv_body             ", &
    "errstat               ", &
    "radiance_body         ", &
    "resat_averaging_kernel", &
    "scatt_body            "  &
/)

contains

subroutine b2o_do_nothing
end subroutine

subroutine b2o_exit(code)

    integer, intent(in) :: code

    interface ! stdlib.h
        subroutine c_exit(code) bind (c, name="exit")
        use, intrinsic :: iso_c_binding
        integer(c_int), value :: code
        end subroutine
    end interface

!    interface ! stdlib.h
!        subroutine c_abort() bind (c, name="abort")
!        use, intrinsic :: iso_c_binding
!        end subroutine
!    end interface

#ifdef B2O_STANDALONE
!    if (code /= 0) call c_abort()
    call c_exit(code)
#else
    call abor1("b2o_exit")
#endif

end subroutine

end module b2o_common
