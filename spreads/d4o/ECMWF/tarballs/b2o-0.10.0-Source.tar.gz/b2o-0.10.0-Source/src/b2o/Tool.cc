#include "b2o/Tool.h"

#include <fcntl.h>  // ::open
#include <unistd.h> // ::close

#include <algorithm>
#include <iostream>
#include <string>
#include <vector>

#include <eccodes.h>

#include <eckit/exception/Exceptions.h>
#include <eckit/filesystem/PathName.h>

#include <odc/api/odc.h>

#include "b2o_api.h"

using namespace std;
using namespace eckit;

namespace {

pair<string, string> split_at(const string& s, size_t pos, size_t gap = 0)
{
    return make_pair(s.substr(0, pos), s.substr(pos == string::npos ? s.size() : pos + gap));
}

pair<string, string> split_on_first(const string& s, const string& d)
{
    return split_at(s, s.find(d), d.size());
}

pair<string, string> split_on_last(const string& s, const string& d)
{
    return split_at(s, s.find_last_of(d), d.size());
}

string column_name_of(const string& name)
{
    string result;
    tie(result, ignore) = split_on_first(name, "@");
    return result;
}

string table_name_of(const string& name)
{
    string result;
    tie(ignore, result) = split_on_first(name, "@");
    return result;
}

string prefix_of(const string& name)
{
    string result;
    tie(result, ignore) = split_on_last(column_name_of(name), "_");
    return result;
}

int suffix_of(const string& name)
{
    string result;
    tie(ignore, result) = split_on_last(column_name_of(name), "_");

    try {
        return stoi(result);
    }
    catch (invalid_argument e) {
        return 0;
    }
}

struct column_attrs_t {
    string name;
    int type;
    int size;
    vector<string> bitfield_names;
    vector<int> bitfield_sizes;
};

vector<column_attrs_t> merge_adjacent_string_columns(const vector<column_attrs_t>& columns) {

    // Merges adjacent string columns that form a long string (e.g. wigosid_[1-4]@hdr -> wigosid@hdr).

    vector<column_attrs_t> new_columns;
    new_columns.reserve(columns.size());

    if (!columns.empty()) {
        new_columns.push_back(columns[0]);
    }

    for (auto i = 1; i < columns.size(); ++i)  {

        const bool are_adjacent_string_columns = (
               columns[i-1].type == ODC_STRING
            && columns[i-1].type == columns[i].type
            && prefix_of(columns[i-1].name) == prefix_of(columns[i].name)
            && suffix_of(columns[i-1].name) == suffix_of(columns[i].name)-1 );

        if (are_adjacent_string_columns) {
            new_columns.back().name = prefix_of(columns[i].name);
            new_columns.back().name += "@" + table_name_of(columns[i].name);
            new_columns.back().size = suffix_of(columns[i].name);
        } else {
            new_columns.push_back(columns[i]);
        }
    }

    return new_columns;
}

vector<column_attrs_t> get_frame_columns(const b2o_frame_t* f) {

    int count = 0;
    b2o_frame_column_count(f, &count);

    vector<column_attrs_t> columns;
    columns.reserve(count);

    for (int index = 0; index < count; ++index) {

        char name[128];
        int type;
        const int size = 1;
        vector<string> bitfield_names;
        vector<int> bitfield_sizes;

        b2o_frame_column_name(f, index, name, sizeof(name));
        tie(type, bitfield_names, bitfield_sizes) = b2o::get_column_attrs(name);
        columns.push_back({name, type, size, bitfield_names, bitfield_sizes});
    }

    return merge_adjacent_string_columns(columns);
}

void set_encoder_columns(odc_encoder_t* e, const vector<column_attrs_t>& columns) {

    ASSERT(e);

    int c_index = 0;

    for (const auto& c: columns) {
        odc_encoder_add_column(e, c.name.c_str(), c.type);
        odc_encoder_column_set_data_size(e, c_index, c.size * sizeof(double));
        if (c.type == ODC_BITFIELD) {
            for (auto i = 0; i < c.bitfield_names.size(); ++i) {
                odc_encoder_column_add_bitfield(e, c_index, c.bitfield_names[i].c_str(), c.bitfield_sizes[i]);
            }
        }
        ++c_index;
    }
}

void encode_frame_to_file_descriptor(odc_encoder_t** e, const b2o_frame_t* f, int fd, bool new_columns) {

    ASSERT(f);

    long width, height, size;
    const void* data = nullptr;
    const bool column_major = false;

    if (new_columns || !*e) {
        if (*e) odc_free_encoder(*e);
        odc_new_encoder(e);
        const auto columns = get_frame_columns(f);
        set_encoder_columns(*e, columns);
    }

    b2o_frame_shape(f, &width, &height);
    b2o_frame_data(f, &data, &size);

    odc_encoder_set_row_count(*e, height);
    odc_encoder_set_data_array(*e, data, width * sizeof(double), height, column_major);
    odc_encode_to_file_descriptor(*e, fd, nullptr);
}

} // namespace (anonymous)

extern "C" {

void b2o_rethrow_current_exception(void* context, int error_code) { throw std::current_exception(); }

} // extern "C"

namespace b2o {

void Tool::usage(ostream& o)
{
    o << " usage: b2o [options] bufr-input [ -o odb-output ]" << endl;
    o << endl;
    o << " options:" << endl;
    o << "   -o FILE                    specify the ODB output file" << endl;
    o << "   --code-mappings-file FILE  path to ODB code mappings file" << endl;
    o << "   --schema-file FILE         path to ODB schema file (e.g. ECMA.sch)" << endl;
    o << "   --all-sky                  extract all-sky data" << endl;
    o << "   --macc                     extract ozone for MACC/CAMS project" << endl;
    o << "   --macc-206                 extract ozone (and standard ozone) for MACC/CAMS project" << endl;
    o << "   --verbose                  turn on verbose output" << endl;
    o << endl;
}

Tool::Tool(int argc, char* argv[])
  : eckit::Tool(argc, argv), odc::tool::CommandLineParser(argc, argv)
{
    b2o_init(argc, argv);
    registerOptionWithArgument("-o");
}

Tool::~Tool()
{}

void Tool::run()
{
    vector<string> arguments = parameters();    

    if (arguments.size() == 1) {
        cout << endl;
        cout << " b2o - convert BUFR data into ODB format" << endl;
        cout << endl;
        usage(cout);
        return;
    }
    else if (arguments.size() != 2) {
        throw eckit::UserError("Invalid number of arguments");
    }

    const string inputFile = arguments[1];
    FILE* input = ::fopen(inputFile.c_str(), "r");
    if (input == nullptr) throw CantOpenFile(inputFile);

    const string outputFile = optionArgument<string>("-o", "");
    const int output = ::open(outputFile.c_str(), O_CREAT|O_TRUNC|O_WRONLY, 0666);
    if (output == -1) throw CantOpenFile(outputFile);

    odc_integer_behaviour(ODC_INTEGERS_AS_DOUBLES);
    odc_set_failure_handler(b2o_rethrow_current_exception, nullptr);

    b2o_context_t* x = nullptr;
    b2o_converter_t* c = nullptr;
    b2o_frame_t* f = nullptr;
    b2o_frame_t* fs = nullptr;

    b2o_new_context(&x, nullptr);
    b2o_new_converter(&c);
    b2o_new_frame(&f);
    b2o_new_frame(&fs);

    b2o_context_set_message_source(x, inputFile.c_str());

    int error;
    bool new_columns;
    codes_handle* h = nullptr;
    odc_encoder_t* e = nullptr;

    while ((h = codes_bufr_handle_new_from_file(nullptr, input, &error)) != nullptr || error != CODES_SUCCESS) {

        const int status = b2o_convert_message_handle(x, c, h, f, &new_columns);

        if (status == B2O_SUCCESS) {

            long width, height;
            b2o_frame_shape(fs, &width, &height);
            const bool encode_frame = (new_columns && height > 0) || height >= 10000;

            if (encode_frame) {
                encode_frame_to_file_descriptor(&e, fs, output, new_columns);
                b2o_frame_clear(fs);
            }

            b2o_frame_append(fs, f);
        }

        codes_handle_delete(h);
    }

    encode_frame_to_file_descriptor(&e, fs, output, new_columns);

    b2o_delete_frame(fs);
    b2o_delete_frame(f);
    b2o_delete_converter(c);
    b2o_delete_context(x);
    odc_free_encoder(e);

    ::fclose(input);
    ::close(output);
}

} // namespace b2o
