#include "b2o_api.h"

extern "C" {

int b2o_convert_message_handle(b2o_context_t* x, b2o_converter_t* c, codes_handle* h, b2o_frame_t* f, bool* new_columns)
{
    const void* data;
    size_t data_size;

    CODES_CHECK(codes_get_message(h, &data, &data_size), CODES_SUCCESS);

    return b2o_convert_message_data(x, c, data, data_size, f, new_columns);
}

} // extern "C"

#include <algorithm>

#include <eckit/config/Resource.h>
#include <eckit/filesystem/PathName.h>
#include <eckit/sql/SQLParser.h>
#include <eckit/sql/SQLSession.h>
#include <eckit/sql/SchemaAnalyzer.h>

#include <odc/api/odc.h>
#include <odc/StringTool.h>
#include <odc/CommandLineParser.h>

using namespace std;

namespace {

eckit::sql::TableDefs parse_schema() {

    char exePath[256];
    b2o_get_executable_path(exePath, sizeof(exePath));
    const string homeDir = eckit::Resource<string>("$B2O_HOME", eckit::PathName(exePath).dirName().dirName().asString());
    const string schemaFile = eckit::Resource<string>("$ODB_SCHEMA_FILE", homeDir + "/share/b2o/ECMA.sch");
    eckit::sql::SQLSession session;
    eckit::sql::SQLParser::parseString(session, odc::StringTool::readFile(schemaFile));
    return session.currentDatabase().schemaAnalyzer().definitions();
}

int type_string_to_int(string type) {

    static const map<string, int> mapping = {

        {"INTEGER", ODC_INTEGER}, {"YYYYMMDD", ODC_INTEGER}, {"HHMMSS", ODC_INTEGER},
        {"PK1INT",  ODC_INTEGER}, {"PK9INT",   ODC_INTEGER}, {"@LINK",  ODC_INTEGER},
        {"REAL",    ODC_REAL   }, {"FLOAT",    ODC_REAL   },
        {"DOUBLE",  ODC_DOUBLE }, {"PK9REAL",  ODC_DOUBLE },
        {"STRING",  ODC_STRING }, {"BITFIELD", ODC_BITFIELD}
    };

    transform(begin(type), end(type), begin(type), ::toupper);

    const auto match = find_if(begin(mapping), end(mapping),
            [&type](const pair<string, int>& p) { return type.find(p.first) != string::npos; });

    return match != end(mapping) ? match->second : ODC_IGNORE;
}

} // namespace (anonymous)

namespace b2o {

tuple<int, vector<string>, vector<int>> get_column_attrs(const string& name) {

    // Takes a fully qualified column name (e.g. column@table) and looks up
    // column attributes in the schema.

    static const eckit::sql::TableDefs tables(parse_schema());

    const auto at = name.find("@");
    const auto column_name = name.substr(0, at);
    const auto table_name = name.substr(at+1);

    const auto table = find_if(begin(tables), end(tables),
            [&table_name](const eckit::sql::TableDef& t) { return t.name() == table_name; });

    if (table == end(tables)) {
        throw eckit::UserError("Unrecognized column qualifier: @" + table_name);
    }

    const auto& columns = table->columns();
    const auto column = find_if(begin(columns), end(columns),
            [&column_name](const eckit::sql::ColumnDef& c) { return c.name() == column_name; });

    if (column == end(columns)) {
        throw eckit::UserError("No match found for column " + column_name + " in table " + table_name);
    }

    int type = type_string_to_int(column->type());
    auto& bitfield_names = column->bitfield().first;
    auto& bitfield_sizes = column->bitfield().second;

    return make_tuple(type, bitfield_names, bitfield_sizes);
}

} // namespace b2o
