module b2o_frame

use, intrinsic :: iso_c_binding

use b2o_internal

implicit none

type :: b2o_frame_t
    character(len=128), allocatable :: column_names(:)
    real(b2o_double), pointer :: data(:,:) => null() ! note: with allocatable, Cray fails on c_loc(frame%data)
    integer(b2o_int) :: width = 0
    integer(b2o_int) :: height = 0
    integer(b2o_int) :: max_height = 0
    type(b2o_frame_t), pointer :: self => null()
end type

#include "b2o_debug.h"

contains

function b2o_new_frame(c_frame) result(status) bind(c)

    type(c_ptr) :: c_frame
    integer(c_int) :: status
    type(b2o_frame_t), pointer :: frame

    allocate(frame)

    frame%self => frame
    c_frame = c_loc(frame)

    status = B2O_SUCCESS

end function

function b2o_delete_frame(c_frame) result (status) bind(c)

    type(c_ptr), value :: c_frame
    integer(c_int) :: status
    type(b2o_frame_t), pointer :: frame, self

    call b2o_assert(c_associated(c_frame))
    call c_f_pointer(c_frame, frame)
    call b2o_assert(associated(frame%self))

    deallocate(frame%data)
    self => frame%self
    deallocate(self)

    status = B2O_SUCCESS

end function

function b2o_frame_column_count(c_frame, count) result(status) bind(c)

    type(c_ptr), value :: c_frame
    integer(c_int), intent(out) :: count
    integer(c_int) :: status
    type(b2o_frame_t), pointer :: frame

    call b2o_assert(c_associated(c_frame))
    call c_f_pointer(c_frame, frame)
    count = size(frame%column_names)

    status = B2O_SUCCESS

end function

function b2o_frame_column_name(c_frame, c_index, c_name, c_name_len) result(status) bind(c)

    type(c_ptr), value :: c_frame
    integer(c_int), value :: c_index
    character(kind=c_char, len=1), dimension(*) :: c_name
    integer(c_int), value :: c_name_len
    integer(c_int) :: status

    type(b2o_frame_t), pointer :: frame

    call b2o_assert(c_associated(c_frame))
    call c_f_pointer(c_frame, frame)
    call b2o_assert(c_name_len > len_trim(frame%column_names(c_index+1)))
    call f_c_string(frame%column_names(c_index+1), c_name, c_name_len)

    status = B2O_SUCCESS

end function

function b2o_frame_shape(c_frame, width, height) result(status) bind(c)

    type(c_ptr), value :: c_frame
    integer(c_long), intent(out) :: width, height
    integer(c_int) :: status
    type(b2o_frame_t), pointer :: frame

    call b2o_assert(c_associated(c_frame))
    call c_f_pointer(c_frame, frame)

    width  = frame%width
    height = frame%height

    status = B2O_SUCCESS

end function

function b2o_frame_data(c_frame, c_data, c_size) result(status) bind(c)

    type(c_ptr), value :: c_frame
    type(c_ptr) :: c_data
    integer(c_long), intent(out) :: c_size
    integer(c_int) :: status
    type(b2o_frame_t), pointer :: frame

    call b2o_assert(c_associated(c_frame))
    call c_f_pointer(c_frame, frame)

    c_data = c_loc(frame%data)
    c_size = frame%width * frame%height * 8

    status = B2O_SUCCESS

end function

function b2o_frame_clear(c_frame) result(status) bind(c)

    type(c_ptr), value :: c_frame
    integer(c_int) :: status
    type(b2o_frame_t), pointer :: frame

    call b2o_assert(c_associated(c_frame))
    call c_f_pointer(c_frame, frame)

    frame%height = 0

    status = B2O_SUCCESS

end function

function b2o_frame_append(c_frame, c_other) result(status) bind(c)

    type(c_ptr), value :: c_frame, c_other
    integer(c_int) :: status
    type(b2o_frame_t), pointer :: frame, other
    real(b2o_double), pointer :: new_data(:,:)
    integer(b2o_int) :: new_height

    call b2o_assert(c_associated(c_frame))
    call b2o_assert(c_associated(c_other))

    call c_f_pointer(c_frame, frame)
    call c_f_pointer(c_other, other)

    if (.not.allocated(frame%column_names)) then
        frame%column_names = other%column_names
        frame%width = other%width
    end if

    call b2o_assert(size(frame%column_names) == size(other%column_names))
    call b2o_assert(frame%width == other%width)
    call b2o_assert(associated(other%data))

    new_height = frame%height + other%height

    if (frame%max_height < new_height) then
        frame%max_height = 2 * new_height
        if (.not.associated(frame%data)) then
            allocate(frame%data(frame%width,frame%max_height))
            frame%data(:,frame%height+1:new_height) = other%data(:,1:other%height)
        else
            allocate(new_data(frame%width,frame%max_height))
            new_data(:,1:frame%height) = frame%data(:,1:frame%height)
            new_data(:,frame%height+1:new_height) = other%data(:,1:other%height)
            deallocate(frame%data)
            frame%data => new_data
        end if
    else
        call b2o_assert(associated(frame%data))
        frame%data(:,frame%height+1:new_height) = other%data(:,1:other%height)
    end if

    frame%height = new_height

    status = B2O_SUCCESS

end function

end module
