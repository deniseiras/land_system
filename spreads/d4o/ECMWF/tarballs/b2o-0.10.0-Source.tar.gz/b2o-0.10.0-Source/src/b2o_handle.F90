module b2o_handle

use b2o_accessor
use b2o_common
use b2o_log_mod
use b2o_table
use b2o_utility, only : b2o_setenv, b2o_get_free_unit

implicit none

#include "b2o_debug.h"

type b2o_handle_t
    integer(b2o_int) :: bufr_id
    character(len=64), pointer :: schema(:) => null()

    integer(b2o_int) :: subtype
    integer(b2o_int) :: reports   ! number of reports (usually equal to subsets)
    integer(b2o_int), dimension(:), pointer :: entries => null()
    integer(b2o_int) :: subset_number = 0

    type(b2o_context_t), pointer :: context => null()
    type(b2o_table_t), pointer :: tables => null()
    type(b2o_link_t), pointer :: links => null()
    class(b2o_accessor_t), allocatable :: accessor

    logical :: new_columns = .true.

    type(b2o_handle_t), pointer :: self => null()
end type

interface b2o_reserve
    module procedure b2o_reserve_regular
    module procedure b2o_reserve_irregular
end interface

interface b2o_log
    module procedure b2o_log_via_handle
end interface

contains

subroutine b2o_log_via_handle(handle, level, text)

    type(b2o_handle_t), intent(in) :: handle
    integer(b2o_int), intent(in) :: level
    character(len=*), intent(in) :: text
    type(b2o_context_t), pointer :: context
    character(len=512) :: extended_text

    context => handle%context

    if (level < context%log_level) then
        return
    end if

    if (context%message_number > 0) then
        write(extended_text, "(a,' [',a,':',i0,']')") &
           & trim(text), trim(context%message_source), context%message_number
        call b2o_log(context, level, extended_text)
    else
        call b2o_log(context, level, text)
    end if

end subroutine

subroutine b2o_new_converter(c_handle) bind(c)

    use, intrinsic :: iso_c_binding

    type(c_ptr) :: c_handle
    type(b2o_handle_t), pointer :: handle
    type(b2o_context_t), pointer :: context
    real(b2o_double) :: hook_handle
    character(len=*), parameter :: hook_label = "b2o_new_converter"

    interface
    function b2o_context_default() result(context)
        use b2o_common
        type(b2o_context_t), pointer :: context
    end function
    end interface

    if (lhook) call dr_hook(hook_label, 0, hook_handle)

    context => b2o_context_default()
    allocate(handle)

    call b2o_converter_initialize(context, handle)

    handle%self => handle
    c_handle = c_loc(handle)

    if (lhook) call dr_hook(hook_label, 1, hook_handle)

end subroutine

subroutine b2o_converter_initialize(context, handle)

    use getval_module, only : getval

    type(b2o_context_t), intent(inout), target :: context
    type(b2o_handle_t), intent(inout) :: handle
    integer(b2o_int) :: ios, npools
    logical :: has_subsets_file
    real(b2o_double) :: hook_handle
    character(len=256) :: message
    character(len=*), parameter :: hook_label = "b2o_converter_initialize"

    handle%context => context

    call b2o_load_schema(context%odb_handle, handle)
    call getval(context%odb_handle)

    ! Load number of subsets per pool from a file (if available) to generate
    ! unique sequence numbers accross the pools.

    has_subsets_file = .false.
    if (len_trim(context%subsets_per_pool_file) /= 0) then
        inquire (file=context%subsets_per_pool_file, exist=has_subsets_file)
    end if

    if (has_subsets_file) then

        open(unit=88, file=context%subsets_per_pool_file, status="old")
        read(88, *, iostat=ios) npools
        if (ios /= 0) then
            write (message, "(a,a)") "Could not read number of subsets per pool: ", &
                & trim(context%subsets_per_pool_file)
            call b2o_log(context, B2O_ERROR, message)
            call b2o_exit(B2O_IO_ERROR)
        endif

        if (.not.associated(context%subsets_per_pool)) then
            allocate(context%subsets_per_pool(context%number_of_pools))
        end if
        call b2o_assert(size(context%subsets_per_pool) >= context%number_of_pools)

        read(88, *, iostat=ios) &
            & context%subsets_per_pool(1:context%number_of_pools)
        if (ios /= 0) then
            write (message, "(a,a)") "Could not read number of subsets per pool: ", &
                & trim(context%subsets_per_pool_file)
            call b2o_log(context, B2O_ERROR, message)
            call b2o_exit(B2O_IO_ERROR)
        endif
        close(88)

    end if
end subroutine

subroutine b2o_delete_converter(c_converter) bind(c)

    use, intrinsic :: iso_c_binding

    type(c_ptr), value :: c_converter
    type(b2o_handle_t), pointer :: converter, self

    call b2o_assert(c_associated(c_converter))
    call c_f_pointer(c_converter, converter)

    call b2o_converter_finalize(converter)

    call b2o_assert(associated(converter%self))
    self => converter%self
    deallocate(self)

end subroutine

subroutine b2o_converter_finalize(handle)

    type(b2o_handle_t), intent(inout) :: handle
    type(b2o_link_t), pointer :: link, next_link
    real(b2o_double) :: hook_handle
    character(len=*), parameter :: hook_label = "b2o_converter_finalize"

    if (lhook) call dr_hook(hook_label, 0, hook_handle)

    call b2o_table_finalize(handle%tables)

    link => handle%links
    do while (associated(link))
        next_link => link%next
        deallocate(link)
        link => next_link
    end do

    if (associated(handle%context%subsets_per_pool)) then
        deallocate(handle%context%subsets_per_pool)
    end if

    if (lhook) call dr_hook(hook_label, 1, hook_handle)

end subroutine

subroutine b2o_reserve_regular(handle, entries_per_report, reports)

    type(b2o_handle_t), intent(inout) :: handle
    integer(b2o_int), intent(in) :: entries_per_report
    integer(b2o_int), intent(in), optional :: reports
    integer(b2o_int) :: n
    real(b2o_double) :: hook_handle
    character(len=*), parameter :: hook_label = "b2o_reserve_regular"

    if (lhook) call dr_hook(hook_label, 0, hook_handle)

    call b2o_assert(entries_per_report > 0)

    n = handle%reports

    if (present(reports)) then
        n = reports ! override number of reports (e.g. in case of thinning)
    end if

    call b2o_reserve_irregular(handle, spread(entries_per_report, 1, n))

    if (lhook) call dr_hook(hook_label, 1, hook_handle)

end subroutine

subroutine b2o_reserve_irregular(handle, entries)

    type(b2o_handle_t), intent(inout) :: handle
    integer(b2o_int), intent(in) :: entries(:)
    type(b2o_table_t), pointer :: table
    real(b2o_double) :: hook_handle
    character(len=*), parameter :: hook_label = "b2o_reserve_irregular"

    if (lhook) call dr_hook(hook_label, 0, hook_handle)

    call b2o_assert(size(entries) > 0)
    call b2o_assert(all(entries > 0))

    table => handle%tables
    do while (associated(table))
        table%is_used = .false.
        table => table%next
    end do

    handle%reports = size(entries)

    if (associated(handle%entries)) then
        if (size(handle%entries) < handle%reports) then
            deallocate(handle%entries)
            allocate(handle%entries(handle%reports))
        end if
    else
        allocate(handle%entries(handle%reports))
    end if

    handle%entries(1:handle%reports) = entries(:)

    if (lhook) call dr_hook(hook_label, 1, hook_handle)

end subroutine

function b2o_use_table(handle, name, table_ptr) result(data)

    type(b2o_handle_t), intent(in) :: handle
    character(len=*), intent(in) :: name
    type(b2o_table_t), pointer, optional :: table_ptr
    real(b2o_double), dimension(:,:), pointer :: data
    type(b2o_table_t), pointer :: table
    integer(b2o_int) :: rows
    real(b2o_double) :: hook_handle
    character(len=*), parameter :: hook_label = "b2o_use_table"

    if (lhook) call dr_hook(hook_label, 0, hook_handle)
    
    table => b2o_table_lookup(handle%tables, name)
    if (.not.associated(table)) then
        call b2o_log(handle%context, B2O_ERROR, "Table not found: " // trim(name))
        call b2o_exit(B2O_INTERNAL_ERROR)
    end if

    select case (table%kind)
    case (B2O_KIND_HEADER)
        rows = handle%reports
    case (B2O_KIND_BODY)
        rows = sum(handle%entries(1:handle%reports))
    case default
        call b2o_log(handle%context, B2O_ERROR, "Unsupported table: " // trim(name))
        call b2o_exit(B2O_INTERNAL_ERROR)
    end select

    call b2o_table_resize(table, rows)

    data => table%data
    table%is_used = .true.
    if (present(table_ptr)) table_ptr => table

    if (lhook) call dr_hook(hook_label, 1, hook_handle)

end function

function b2o_next_subset(handle) result(has_next)

    type(b2o_handle_t), intent(inout) :: handle
    logical :: has_next
    integer(b2o_int) :: subsets
    real(b2o_double) :: hook_handle
    character(len=*), parameter :: hook_label = "b2o_next_subset"

    if (lhook) call dr_hook(hook_label, 0, hook_handle)

    call codes_get(handle%bufr_id, "numberOfSubsets", subsets)

    handle%subset_number = handle%subset_number + 1
    has_next = handle%subset_number <= subsets

    if (lhook) call dr_hook(hook_label, 1, hook_handle)

end function

subroutine b2o_handle_shrink(handle, n_reports)

    type(b2o_handle_t), intent(inout) :: handle
    integer(b2o_int), intent(in) :: n_reports
    type(b2o_table_t), pointer :: table
    integer(b2o_int) :: total_entries
    real(b2o_double) :: hook_handle
    character(len=*), parameter :: hook_label = "b2o_handle_shrink"

    if (lhook) call dr_hook(hook_label, 0, hook_handle)

    call b2o_assert(n_reports <= handle%reports)

    handle%reports = n_reports
    total_entries = sum(handle%entries(1:handle%reports))

    table => handle%tables
    do while (associated(table))
        if (table%is_used) then
            select case (table%kind)
            case (B2O_KIND_HEADER) ; table%rows = handle%reports
            case (B2O_KIND_BODY)   ; table%rows = total_entries
            end select
        end if
        table => table%next
    end do

    if (lhook) call dr_hook(hook_label, 1, hook_handle)

end subroutine

function b2o_pack(handle, mask) result(rows)

    type(b2o_handle_t), intent(inout) :: handle
    logical, intent(in) :: mask(:)
    integer(b2o_int) :: rows, j
    type(b2o_table_t), pointer :: table

    ! At the momment, this function only makes sense for single reports.
    call b2o_assert(handle%reports == 1)
    call b2o_assert(size(mask) == handle%entries(1))

    if (all(mask)) then
        rows = size(mask)
        return
    end if

    rows = count(mask)

    table => handle%tables
    do while (associated(table))
        if (table%is_used .and. table%kind == B2O_KIND_BODY) then
            call b2o_table_pack(table, mask, rows)
        end if
        table => table%next
    end do

    handle%entries(1) = rows

end function

function b2o_pack_reports(handle, report_mask) result(report_count)

    type(b2o_handle_t), intent(inout) :: handle
    logical, intent(in) :: report_mask(:)
    logical, allocatable :: entry_mask(:)
    integer(b2o_int) :: report_count, entry_count, i, lo, hi
    type(b2o_table_t), pointer :: table

    call b2o_assert(size(report_mask) == handle%reports)

    if (all(report_mask)) then
        report_count = handle%reports
        return
    end if

    allocate(entry_mask(sum(handle%entries(1:handle%reports))))

    lo = 1
    do i = 1, handle%reports
        hi = lo + handle%entries(i) - 1
        entry_mask(lo:hi) = report_mask(i)
        lo = hi + 1
    end do

    report_count = count(report_mask)
    entry_count = count(entry_mask)

    table => handle%tables
    do while (associated(table))
        if (table%is_used) then
            select case (table%kind)
            case (B2O_KIND_HEADER) ; call b2o_table_pack(table, report_mask, report_count)
            case (B2O_KIND_BODY)   ; call b2o_table_pack(table, entry_mask, entry_count)
            end select
        end if
        table => table%next
    end do

    handle%entries(1:report_count) = pack(handle%entries(1:handle%reports), report_mask)
    handle%reports = report_count

end function

#ifdef B2O_STANDALONE

subroutine b2o_load_schema(h, handle)

    use b2o_option, only : ODB_SCHEMA_FILE

    integer(b2o_int), intent(in) :: h
    type(b2o_handle_t), intent(inout), target :: handle
    integer(b2o_int) :: i, status
    type(b2o_context_t), pointer :: context
    integer(b2o_int) :: unit, count
    real(b2o_double) :: hook_handle
    character(len=*), parameter :: hook_label = "b2o_load_schema"

    if (lhook) call dr_hook(hook_label, 0, hook_handle)

    context => handle%context

    call b2o_log(context, B2O_INFO, "Loading ODB schema from: " // trim(ODB_SCHEMA_FILE))

    unit = b2o_get_free_unit()
    open(unit=unit, file=ODB_SCHEMA_FILE, status="old", iostat=status)
    if (status /= 0) then
        call b2o_log(context, B2O_ERROR, "Could not open ODB schema file: " // trim(ODB_SCHEMA_FILE))
        call b2o_exit(B2O_IO_ERROR)
    end if

    ! Get the number of rows in the schema file
    count = 0
    rewind(unit)
    do while (.true.)
        read(unit, fmt=*, iostat=status)
        if (status == 0) then
            count = count + 1
        else
            exit
        end if
    end do
    rewind(unit)

    call b2o_assert(.not.associated(handle%schema))
    allocate(handle%schema(count))

    do i = 1, count
        read(unit, fmt="(a)", iostat=status) handle%schema(i)
        if (status /= 0) then
            call b2o_log(context, B2O_ERROR, "Error while reading ODB schema file: " // trim(ODB_SCHEMA_FILE))
            call b2o_exit(B2O_IO_ERROR)
        end if
    end do
    close(unit)

    call get_varindex(handle, h)

    call b2o_assert(associated(handle%schema))
    deallocate(handle%schema)

    if (lhook) call dr_hook(hook_label, 1, hook_handle)

end subroutine

#else

subroutine b2o_load_schema(h, handle)

    use odb_module, only : odb_getnames

    integer(b2o_int), intent(in) :: h
    type(b2o_handle_t), intent(inout), target :: handle
    type(b2o_table_t), pointer :: table, parent_table, child_table
    type(b2o_link_t), pointer :: link, new_link
    character(len=64), dimension(:), allocatable :: table_names, column_names, column_types
    character(len=64) :: name, child_name, column_name
    integer(b2o_int) :: i, j, n
    real(b2o_double) :: hook_handle
    character(len=*), parameter :: hook_label = "b2o_load_schema"

    if (lhook) call dr_hook(hook_label, 0, hook_handle)

    call get_varindex(handle, h)

    n = odb_getnames(h, "*", "table")
    allocate(table_names(n))
    n = odb_getnames(h, "*", "table", table_names)

    do i = 1, size(table_names)

        n = odb_getnames(h, table_names(i), "name")
        name = table_names(i)(2:) ! ignore '@' prefix

        if (n > 0 .and. b2o_table_kind(name) /= B2O_KIND_UNKNOWN) then
            allocate(column_names(n))
            allocate(column_types(n))
            n = odb_getnames(h, table_names(i), "name", column_names)
            n = odb_getnames(h, table_names(i), "type", column_types)
            table => b2o_new_table(handle%context, handle%tables, name, column_names, column_types)
            deallocate(column_names)
            deallocate(column_types)
        end if

    end do

    deallocate(table_names)

    link => null()
    parent_table => handle%tables

    do while (associated(parent_table))

        n = odb_getnames(h, "@"//trim(parent_table%name), "name")
        if (n == 0) exit ! TODO: shouldn't it be cycle?
        allocate(column_names(n))
        n = odb_getnames(h, "@"//trim(parent_table%name), "name", column_names)

        do j = 1, size(column_names)
            column_name = column_names(j)
            if (column_name(1:10) == "LINKOFFSET") then
                child_name = column_name(12:index(column_name, ")")-1)
                child_table => b2o_table_lookup(handle%tables, child_name)
                if (associated(child_table)) then
                    allocate(new_link)
                    if (associated(link)) then
                        link%next => new_link
                    else
                        handle%links => new_link
                    end if
                    link => new_link
                    link%parent => parent_table
                    link%child => child_table
                    link%offset_index = j
                    link%length_index = j + 1
                end if
            end if
        end do

        deallocate(column_names)
        parent_table => parent_table%next

    end do

    if (lhook) call dr_hook(hook_label, 1, hook_handle)

end subroutine

#endif

#ifdef B2O_STANDALONE

subroutine b2o_varindex(handle, h, table_name, column_names, column_indices)

    type(b2o_handle_t), intent(inout) :: handle
    integer(b2o_int), intent(in) :: h
    type(b2o_table_t), pointer :: table
    character(len=*), intent(in) :: table_name
    character(len=*), dimension(:), intent(in) :: column_names
    integer(b2o_int), dimension(:), intent(out) :: column_indices
    integer(b2o_int) :: i, j, k, m, n, p, status
    character(len=64), dimension(size(column_names)) :: column_types
    character(len=64) :: row
    real(b2o_double) :: hook_handle
    character(len=*), parameter :: hook_label = "b2o_varindex"

    if (lhook) call dr_hook(hook_label, 0, hook_handle)

    call b2o_assert(size(column_names) == size(column_indices))
    call b2o_assert(associated(handle%schema))

    j = 0
    do i = 1, size(handle%schema)
        if (index(handle%schema(i), "TABLE " // trim(table_name(2:))) > 0) then
            j = i
            exit
        end if
    end do

    if (j == 0) then
        call b2o_log(handle%context, B2O_ERROR, "Table definition not found: " // table_name(2:))
        call b2o_exit(B2O_INTERNAL_ERROR)
    end if

    column_types(:) = ""

    do i = 1, size(column_types)

        ! Special treatment of link offset/length columns
        if (column_names(i)(1:10) == "linkoffset") then
            column_types(i) = "linkoffset_t"
            continue
        end if

        ! Find column type in table definition
        do k = j + 1, size(handle%schema)
            row = trim(handle%schema(k))
            m = index(row, trim(column_names(i)))
            if (m > 0) then
                row = row(m:)
                n = index(row, " ")
                p = index(row, ",")
                column_types(i) = trim(row(n+1:p-1))
                exit
            end if
        end do

        if (len_trim(column_types(i)) == 0) then
            call b2o_log(handle%context, B2O_ERROR, "Column definition not found: " &
                    & // trim(column_names(i)))
            call b2o_exit(B2O_INTERNAL_ERROR)
        end if
    end do

    table => b2o_new_table(handle%context, handle%tables, table_name(2:), column_names, column_types)

    do i = 1, size(column_indices)
        column_indices(i) = i
    end do

    if (lhook) call dr_hook(hook_label, 1, hook_handle)

end subroutine

#else

subroutine b2o_varindex(h, handle, table_name, column_names, column_indices)

    use odb_module, only : odb_varindex

    type(b2o_handle_t), intent(inout) :: h
    integer(b2o_int), intent(in) :: handle
    character(len=*), intent(in) :: table_name
    character(len=*), dimension(:), intent(in) :: column_names
    integer(b2o_int), dimension(:), intent(out) :: column_indices
    integer(b2o_int) :: status
    character(len=128) :: message
    real(b2o_double) :: hook_handle
    character(len=*), parameter :: hook_label = "b2o_varindex"

    if (lhook) call dr_hook(hook_label, 0, hook_handle)

    status = odb_varindex(handle, table_name, column_names, column_indices)

    if (status < 0) then
        write(message, "(a, i0)") "Call to odb_varindex() failed: ", status
        call b2o_log(h%context, B2O_ERROR, message)
        call b2o_exit(-99)
    end if

    if (lhook) call dr_hook(hook_label, 1, hook_handle)

end subroutine

#endif

end module
