module b2o_internal

use varindex_module
use getval_module

#ifndef B2O_STANDALONE
use odb_module
#endif

use b2o_common
use b2o_table
use b2o_handle
use b2o_utility
use b2o_get
use b2o_log_mod

implicit none

#include "b2o_debug.h"

interface

! b2o_context

function b2o_context_default() result(context)
    use b2o_common
    type(b2o_context_t), pointer :: context
end function

subroutine b2o_context_set_log_proc(context, log_proc)
    use b2o_common
    type(b2o_context_t), intent(inout) :: context
    procedure(b2o_log_proc), pointer :: log_proc
end subroutine

end interface

type(b2o_context_t), target, save :: the_default_context

contains

subroutine b2o_get_column_name(handle, index, name)

    type(b2o_handle_t), intent(in) :: handle
    integer(b2o_int), intent(in) :: index
    character(len=64), intent(out) :: name
    type(b2o_table_t), pointer :: table
    integer(b2o_int) :: i
    real(b2o_double) :: hook_handle
    character(len=*), parameter :: hook_label = "b2o_get_column_name"

    if (lhook) then
        call dr_hook(hook_label, 0, hook_handle)
    end if

    i = index
    table => handle%tables

    do while (associated(table))
        if (table%is_used) then
            if ((i - table%columns) > 0) then
                i = i - table%columns
            else
                exit
            end if
        end if
        table => table%next
    end do

    call b2o_assert(associated(table))
    call b2o_assert(associated(table%column_names))
    name = trim(table%column_names(i)) // "@" // trim(table%name)
    
    if (lhook) then
        call dr_hook(hook_label, 1, hook_handle)
    end if

end subroutine

subroutine c_b2o_get_column_name(c_handle, c_index, c_name, c_length) &
    & bind(c, name="b2o_get_column_name")

    use iso_c_binding

    type(c_ptr), value :: c_handle
    integer(c_int), value :: c_index
    character(kind=c_char, len=1), dimension(*) :: c_name
    integer(c_size_t), value :: c_length

    type(b2o_handle_t), pointer :: handle
    character(len=64) :: name
    real(b2o_double) :: hook_handle
    character(len=*), parameter :: hook_label = "c_b2o_get_column_name"

    if (lhook) then
        call dr_hook(hook_label, 0, hook_handle)
    end if

    call b2o_assert(c_associated(c_handle))
    call c_f_pointer(c_handle, handle)
    call b2o_get_column_name(handle, c_index + 1, name)
    call b2o_assert(c_length > len_trim(name))
    call f_c_string(name, c_name, int(c_length, kind=b2o_int))

    if (lhook) then
        call dr_hook(hook_label, 1, hook_handle)
    end if

end subroutine

#ifndef B2O_STANDALONE

subroutine odb_put_message(odb_handle_, handle, pool_number)

    integer(b2o_int), intent(in) :: odb_handle_
    type(b2o_handle_t), intent(inout) :: handle
    integer(b2o_int), intent(in) :: pool_number
    integer(b2o_int) :: status
    type(b2o_table_t),  pointer :: table
    character(len=128) :: message
    real(b2o_double) :: hook_handle
    character(len=*), parameter :: hook_label = "odb_put_message"

    if (lhook) then
        call dr_hook(hook_label, 0, hook_handle)
    end if

    table => handle%tables

    do while (associated(table))

        if (.not.table%is_used) then
            table => table%next
            cycle
        end if

        status = odb_put(odb_handle_, "@"//trim(table%name), &
            & table%data, table%rows, poolno=pool_number)

        if (status < 0) then
            write(message, "(a, i0)") "Call to odb_put() failed: ", status
            call b2o_log(handle%context, B2O_ERROR, message)
            call b2o_exit(-99)
        end if
        table => table%next

    end do

    if (lhook) then
        call dr_hook(hook_label, 1, hook_handle)
    end if

end subroutine

#endif

end module b2o_internal
