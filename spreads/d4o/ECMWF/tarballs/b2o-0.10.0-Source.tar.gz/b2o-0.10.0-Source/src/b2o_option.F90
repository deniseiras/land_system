module b2o_option

use b2o_common

implicit none

integer, parameter, private :: MAX_LEN = 256

logical :: B2O_ALL_SKY
logical :: B2O_CAMS_AND_IFS_OZONE
logical :: B2O_CAMS_OZONE
logical :: B2O_EXTRACT_RH2M
logical :: B2O_HELP
logical :: B2O_TEMP_ASCENT_BATCH_AVERAGING
logical :: B2O_TEMP_DESCENT_BATCH_AVERAGING
logical :: B2O_TEMP_DROP_BATCH_AVERAGING
logical :: B2O_UNIQUE_SEQNO
logical :: B2O_VERBOSE

integer(b2o_int) :: B2O_LOG_LEVEL
integer(b2o_int) :: B2O_TEMP_ASCENT_BATCH_INTERVAL
integer(b2o_int) :: B2O_TEMP_DESCENT_BATCH_INTERVAL
integer(b2o_int) :: B2O_TEMP_DROP_BATCH_INTERVAL
integer(b2o_int) :: B2O_TEMP_MAX_LEVELS
integer(b2o_int) :: B2O_THINNING_INTERVAL

real(b2o_double) :: B2O_STATION_POSITION_TOLERANCE
real(b2o_double) :: B2O_STATION_HEIGHT_TOLERANCE

character(len=MAX_LEN) :: B2O_AIRCRAFT_TYPE_MAPPINGS
character(len=MAX_LEN) :: B2O_CRIS_CHANNELS
character(len=MAX_LEN) :: B2O_IASI_CHANNELS
character(len=MAX_LEN) :: ODB_CODE_MAPPINGS
character(len=MAX_LEN) :: ODB_SCHEMA_FILE

contains

subroutine parse_command_line(args)

    use b2o_common, only : B2O_ERROR

    character(len=*), intent(inout) :: args(:)

    interface set
        procedure set_bool
        procedure set_int
        procedure set_double
        procedure set_string
    end interface

    call set(B2O_AIRCRAFT_TYPE_MAPPINGS, path_to("aircraft_type_mappings.csv"), env="B2O_AIRCRAFT_TYPE_MAPPINGS", flag="--airctaft-type-mappings")
    call set(B2O_ALL_SKY, .false., env="B2O_ALL_SKY", flag="--all-sky")
    call set(B2O_CAMS_AND_IFS_OZONE, .false., flag="--cams-and-ifs-ozone")
    call set(B2O_CAMS_OZONE, .false., flag="--cams-ozone")
    call set(B2O_CRIS_CHANNELS, path_to("crischannels"), env="B2O_CRIS_CHANNELS", flag="--cris-channels")
    call set(B2O_EXTRACT_RH2M, .true., env="B2O_EXTRACT_RH2M")
    call set(B2O_HELP, .false., flag="--help")
    call set(B2O_IASI_CHANNELS, path_to("iasichannels"), env="B2O_IASI_CHANNELS", flag="--iasi-channels")
    call set(B2O_LOG_LEVEL, B2O_ERROR, env="B2O_LOG_LEVEL", flag="--log-level")
    call set(B2O_STATION_HEIGHT_TOLERANCE, 5.0d0, env="B2O_STATION_HEIGHT_TOLERANCE")
    call set(B2O_STATION_POSITION_TOLERANCE, 0.1d0, env="B2O_STATION_POSITION_TOLERANCE")
    call set(B2O_TEMP_ASCENT_BATCH_AVERAGING, .false., env="B2O_TEMP_ASCENT_BATCH_AVERAGING")
    call set(B2O_TEMP_ASCENT_BATCH_INTERVAL, 15*60, env="B2O_TEMP_ASCENT_BATCH_INTERVAL")
    call set(B2O_TEMP_DESCENT_BATCH_AVERAGING, .false., env="B2O_TEMP_DESCENT_BATCH_AVERAGING")
    call set(B2O_TEMP_DESCENT_BATCH_INTERVAL, 5*60, env="B2O_TEMP_DESCENT_BATCH_INTERVAL")
    call set(B2O_TEMP_DROP_BATCH_AVERAGING, .false., env="B2O_TEMP_DROP_BATCH_AVERAGING")
    call set(B2O_TEMP_DROP_BATCH_INTERVAL, 1*60, env="B2O_TEMP_DROP_BATCH_INTERVAL")
    call set(B2O_TEMP_MAX_LEVELS, 5000, env="B2O_TEMP_MAX_LEVELS")
    call set(B2O_THINNING_INTERVAL, 1, flag="--thinning-interval")
    call set(B2O_UNIQUE_SEQNO, .false., env="B2O_UNIQUE_SEQNO", flag="--unique-seqno")
    call set(B2O_VERBOSE, .false., env="B2O_VERBOSE", flag="--verbose")
    call set(ODB_CODE_MAPPINGS, path_to("odb_code_mappings.dat"), env="ODB_CODE_MAPPINGS", flag="--code-mappings")
    call set(ODB_SCHEMA_FILE, path_to("ECMA.sch"), env="ODB_SCHEMA_FILE", flag="--schema-file")

contains

subroutine set_string(option, default, env, flag)

    character(len=*), intent(inout) :: option
    character(len=*), intent(in) :: default
    character(len=*), intent(in), optional :: env, flag
    character(len=len(option)) :: value
    integer :: i, j

    option = default

    if (present(env)) then

        call get_environment_variable(env, value)

        if (len_trim(value) > 0) then
            read (value, fmt="(a)") option
        end if

    end if

    if (present(flag)) then 

        value = ""

        do i = 1, size(args)    
            if (index(args(i), trim(flag)) > 0) then
                j = index(args(i), "=")
                if (j > 0) then
                    value = args(i)(j+1:)
                else
                    value = args(i+1)
                    args(i+1) = ""
                end if
                args(i) = ""
                exit
            end if
        end do

        if (len_trim(value) > 0) then
            read(value, fmt="(a)") option
        end if

    end if

end subroutine

subroutine set_double(option, default, env, flag)

    real(b2o_double), intent(inout) :: option
    real(b2o_double), intent(in) :: default
    character(len=*), intent(in), optional :: env, flag
    character(len=16) :: value
    integer :: i, j, iostat

    option = default

    if (present(env)) then

        call get_environment_variable(env, value)

        if (len_trim(value) > 0) then
            read (value, fmt=*, iostat=iostat) option
            if (iostat /= 0) then
                write (6,*) "Invalid $" // trim(env) // " value: " // trim(value) // " (expected float)"
                call b2o_exit(1)
            end if
        end if

    end if

    if (present(flag)) then 

        value = ""

        do i = 1, size(args)    
            if (index(args(i), trim(flag)) > 0) then
                j = index(args(i), "=")
                if (j > 0) then
                    value = args(i)(j+1:)
                else
                    value = args(i+1)
                    args(i+1) = ""
                end if
                args(i) = ""
                exit
            end if
        end do

        if (len_trim(value) > 0) then
            read(value, fmt=*, iostat=iostat) option
            if (iostat /= 0) then
                write (6,*) "Invalid " // trim(flag) // " argument: '" // trim(value) // "' (expected integer)"
                call b2o_exit(1)
            end if
        end if

    end if

end subroutine

subroutine set_int(option, default, env, flag)

    integer(b2o_int), intent(inout) :: option
    integer(b2o_int), intent(in) :: default
    character(len=*), intent(in), optional :: env, flag
    character(len=16) :: value
    integer :: i, j, iostat

    option = default

    if (present(env)) then

        call get_environment_variable(env, value)

        if (len_trim(value) > 0) then
            read (value, fmt=*, iostat=iostat) option
            if (iostat /= 0) then
                write (6,*) "Invalid $" // trim(env) // " value: " // trim(value) // " (expected integer)"
                call b2o_exit(1)
            end if
        end if

    end if

    if (present(flag)) then 

        value = ""

        do i = 1, size(args)    
            if (index(args(i), trim(flag)) > 0) then
                j = index(args(i), "=")
                if (j > 0) then
                    value = args(i)(j+1:)
                else
                    value = args(i+1)
                    args(i+1) = ""
                end if
                args(i) = ""
                exit
            end if
        end do

        if (len_trim(value) > 0) then
            read(value, fmt=*, iostat=iostat) option
            if (iostat /= 0) then
                write (6,*) "Invalid " // trim(flag) // " argument: '" // trim(value) // "' (expected integer)"
                call b2o_exit(1)
            end if
        end if

    end if

end subroutine

subroutine set_bool(option, default, env, flag)

    logical, intent(inout) :: option
    logical, intent(in) :: default
    character(len=*), intent(in), optional :: env, flag
    character(len=:), allocatable :: value
    integer :: i, n

    option = default

    if (present(env)) then

        call get_environment_variable(env, length=n)
        allocate(character(len=n+1) :: value)
        call get_environment_variable(env, value)

        select case (trim(value))
        case ("1","on" ,"ON" ,"true" ,"TRUE")  ; option = .true.
        case ("0","off","OFF","false","FALSE") ; option = .false.
        case ("")                              ; option = default
        case default
            write (6,*) "Invalid $" // trim(env) // " value: " // trim(value) // " (expected bool: 0|1|on|off|true|false)"
            call b2o_exit(1)
        end select

    end if

    if (present(flag)) then

        do i = 1, size(args)    
            if (index(args(i), trim(flag)) > 0) then
                option = (.not. default)
                args(i) = ""
                exit
            end if
        end do

    end if

end subroutine

function path_to(filename) result(path)

    use b2o_utility, only : b2o_get_executable_path

    character(len=*), intent(in) :: filename
    character(len=MAX_LEN) :: path

    call get_environment_variable("B2O_HOME", path)

    if (len_trim(path) == 0) then
        call b2o_get_executable_path(path)
        path = path(:index(path, "/", back=.true.)-1)
        path = path(:index(path, "/", back=.true.)-1)
    end if

    path = trim(path) // "/share/b2o/" // trim(filename)

end function

end subroutine parse_command_line

subroutine b2o_init()

    character(len=:), allocatable :: args(:)
    integer :: i, max_len, n

    max_len = 0

    do i = 1, command_argument_count()
        call get_command_argument(i, length=n)
        max_len = max(max_len, n)
    end do

    allocate(character(len=max_len) :: args(command_argument_count()))

    do i = 1, size(args)
        call get_command_argument(i, args(i))
    end do

    call parse_command_line(args)

end subroutine

subroutine c_b2o_init(c_argc, c_argv) bind(c, name="b2o_init")

    use, intrinsic :: iso_c_binding
    use b2o_utility, only : c_f_string

    integer(c_int), value :: c_argc
    type(c_ptr), intent(in) :: c_argv(*)
    character(kind=c_char), pointer :: c_arg
    character(len=MAX_LEN), allocatable :: f_args(:)
    integer :: i

    allocate(f_args(c_argc-1))

    do i = 1, c_argc-1
        call c_f_pointer(c_argv(i+1), c_arg)
        call c_f_string(c_arg, f_args(i))
    end do

    call parse_command_line(f_args)

end subroutine

end module
