FUNCTION DATASTREAM(BUFRTYPE,BUFRSUBTYPE,&
 &   GEN_CENTRE,GEN_SUBCENTRE,SATID)

USE PARKIND1  ,ONLY : JPRD

IMPLICIT NONE

REAL(KIND=JPRD)   :: DATASTREAM

REAL(KIND=JPRD), INTENT(IN)   :: BUFRTYPE
REAL(KIND=JPRD), INTENT(IN)   :: BUFRSUBTYPE
REAL(KIND=JPRD), INTENT(IN)   :: GEN_CENTRE
REAL(KIND=JPRD), INTENT(IN)   :: GEN_SUBCENTRE
REAL(KIND=JPRD), INTENT(IN)   :: SATID


!  11/11/2008   I. Genkova     Modify db MODIS datastream
!======================================


DATASTREAM = 0._jprd          ! Global data is default

IF(          BUFRTYPE    == 3._jprd            & ! SATEM
 &     .AND. BUFRSUBTYPE == 55._jprd ) THEN      ! ATOVS

  ! Special streams for ATOVS data
  !-------------------------------

  IF(          GEN_CENTRE    == 254._jprd      &   ! EUMETSAT
   &     .AND. GEN_SUBCENTRE > 0._jprd ) THEN      ! Some sub-centre
    DATASTREAM = 1._jprd                            ! EARS

  ELSEIF(     GEN_CENTRE <= 69._jprd .OR. GEN_CENTRE == 110 ) THEN      
    DATASTREAM = 2._jprd                            ! Pacific RARS

  ENDIF

ELSEIF(       BUFRTYPE    == 5._jprd            & ! SATOB/AMV
 &      .AND. BUFRSUBTYPE == 87._jprd ) THEN      ! Ext. AMV with QI

  ! Special streams for AMVs 
  !-------------------------



  IF( ( GEN_CENTRE == 173._jprd .OR. GEN_CENTRE == 176._jprd  & ! CIMSS
   &    .OR.( GEN_CENTRE == 160._jprd              & ! NESDIS
   &          .AND. GEN_SUBCENTRE > 0._jprd )  )   &
   &  .AND. ( SATID == 783 .OR. SATID == 784) ) THEN
    DATASTREAM = 1._jprd                             ! Direct broadcast MODIS
  ENDIF

ELSEIF(       BUFRTYPE    == 12._jprd            & ! SCATT
 &      .AND. BUFRSUBTYPE == 139._jprd           & ! ASCAT
 &      .AND. GEN_SUBCENTRE > 0._jprd  ) THEN      ! Non-EUMETSAT 
    DATASTREAM = 1._jprd                           ! EARS
END IF


END FUNCTION DATASTREAM
