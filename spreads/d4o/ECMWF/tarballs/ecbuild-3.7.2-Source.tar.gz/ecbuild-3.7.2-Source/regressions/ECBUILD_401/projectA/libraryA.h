int libraryA();
